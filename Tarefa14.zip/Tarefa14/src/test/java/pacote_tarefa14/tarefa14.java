//01 - pacote
package pacote_tarefa14;

//02 - bibliotecas


import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;

import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;


//03 - classe
public class tarefa14 {
    //3.1 - Atributos = Caracter�sticas
    String url;
    WebDriver driver;
    String pastaPrint = "evidencias/" + new SimpleDateFormat("yyyy-MM-dd HH-mm").format(Calendar.getInstance().getTime()) + "/";


    //3.2 - m�todos ou fun��es
    //m�todos ou fun��es de apoio (util/commons)
    public void tirarPrint(String nomePrint) throws IOException {
        File foto = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(foto,new File(pastaPrint + nomePrint +".png"));

    }


    //3.2 - M�todos e funcionalidades = O que vai fazer (m�todo executa sem retorno)
    @Before
    public void logar() {
        url = "https://iterasys.com.br"; // declarando o conte�do da String url
        // Liga��o do Webdriver Selenium com o Chrome (browser)
        System.setProperty("webdriver.chrome.driver", "drivers/chrome/87/chromedriver.exe");

        //Instanciar o objeto Selenium WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize(); // maximiza a tela
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.MILLISECONDS);



    }
    @After
    public void finalizar (){
        //driver.quit(); // finalizar(destroi) o objeto Selenium Webdriver

    }

    @Test
    public void login () throws IOException, InterruptedException {
        driver.get(url);
        tirarPrint("01 - Acesso ao site da Iterasys");
        driver.findElement(By.cssSelector("i.fa.fa-sign-in")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("email")).sendKeys(Keys.chord("cleber2011@gmail.com"));
        Thread.sleep(2000);
        driver.findElement(By.id("senha")).sendKeys(Keys.chord("Iterasys2020"));
        Thread.sleep(2000);
        tirarPrint("02 - Preenche usu�rio e senha");
        driver.findElement(By.id("btn_login")).click();
        tirarPrint("03 - Mostra os Meus Cursos dispon�veis");
        // Validar bot�o Meus Cursos
        assertEquals("Meus Cursos",driver.findElement(By.id("btn_my")).getText());

    }

}
